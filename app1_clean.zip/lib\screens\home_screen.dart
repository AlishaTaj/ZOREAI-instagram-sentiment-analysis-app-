import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';  // ✅ Import provider for theme management
import '../providers/theme_provider.dart';  // ✅ Import the theme provider
import 'category_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _responseMessage = '';
  final TextEditingController _loginIdController = TextEditingController();
  bool isLoading = false; // Loading indicator

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final isDarkMode = themeProvider.themeMode == ThemeMode.dark;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Zore AI - Dashboard',
          style: GoogleFonts.poppins(
            color: Theme.of(context).textTheme.bodyLarge?.color,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(
          color: Theme.of(context).iconTheme.color,
        ),
        actions: [
          Switch(
            value: isDarkMode,
            onChanged: (value) {
              themeProvider.toggleTheme(value);
            },
            activeColor: Theme.of(context).iconTheme.color,
          ),
        ],
      ),
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: isLoading
          ? Center(child: CircularProgressIndicator(color: Theme.of(context).iconTheme.color))
          : Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Hello, Alisha!',
              style: GoogleFonts.poppins(
                fontSize: 24,
                color: Theme.of(context).textTheme.bodyLarge?.color,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              'Welcome to your personalized analytics dashboard.',
              style: GoogleFonts.poppins(
                fontSize: 16,
                color: Theme.of(context).textTheme.bodyMedium?.color?.withOpacity(0.7),
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                childAspectRatio: 1.5,
                children: [
                  CategoryCard(
                    title: 'Profile Analysis',
                    icon: Icons.person,
                    onTap: () {
                      Navigator.pushNamed(context, '/profile-analysis');
                    },
                  ),
                  CategoryCard(
                    title: 'Brand Analysis',
                    icon: Icons.business,
                    onTap: () {
                      Navigator.pushNamed(context, '/brand-input');
                    },
                  ),
                  CategoryCard(
                    title: 'Influencer Analysis',
                    icon: Icons.people,
                    onTap: () {
                      Navigator.pushNamed(context, '/influencer-analysis');
                    },
                  ),
                  CategoryCard(
                    title: 'Hashtag Analysis',
                    icon: Icons.tag,
                    onTap: () {
                      Navigator.pushNamed(context, '/hashtag-analysis');
                    },
                  ),
                  CategoryCard(
                    title: 'Content Analysis',
                    icon: Icons.article,
                    onTap: () {
                      Navigator.pushNamed(context, '/content-analysis');
                    },
                  ),
                  CategoryCard(
                    title: 'Engagement Metrics',
                    icon: Icons.analytics,
                    onTap: () {
                      Navigator.pushNamed(context, '/engagement-metrics');
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}