import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';

class AnalyticsScreen extends StatefulWidget {
  final String firstName;

  const AnalyticsScreen({super.key, required this.firstName});

  @override
  _AnalyticsScreenState createState() => _AnalyticsScreenState();
}

class _AnalyticsScreenState extends State<AnalyticsScreen> {
  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final bool isDarkMode = Theme.of(context).brightness == Brightness.dark;

    final Color primaryPurple = const Color(0xFF9D4EDD);
    final Color deepPurple = const Color(0xFF5A189A);
    final Color cardColor = isDarkMode ? const Color(0xFF2A2A2A) : Colors.white;
    final Color textColor = isDarkMode ? Colors.white : Colors.black;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Analytics',
          style: GoogleFonts.poppins(fontSize: 18, color: textColor, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: textColor),
      ),
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildGreetingText(widget.firstName, deepPurple, primaryPurple),
            const SizedBox(height: 5),
            Text(
              'Here are your personalized analytics insights:',
              style: GoogleFonts.poppins(fontSize: 14, color: textColor),
            ),
            const SizedBox(height: 15),

            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                children: [
                  _buildCategoryCard('Profile Analysis', Icons.person, '/profile-analysis', primaryPurple, deepPurple, cardColor, textColor, isDarkMode),
                  _buildCategoryCard('Brand Analysis', Icons.business, '/brand-input', primaryPurple, deepPurple, cardColor, textColor, isDarkMode),
                  _buildCategoryCard('Influencer Analysis', Icons.people, '/influencer-analysis', primaryPurple, deepPurple, cardColor, textColor, isDarkMode),
                  _buildCategoryCard('Hashtag Analysis', Icons.tag, '/hashtag-analysis', primaryPurple, deepPurple, cardColor, textColor, isDarkMode),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// 🎨 **Greeting Text with Gradient**
  Widget _buildGreetingText(String firstName, Color startColor, Color endColor) {
    return ShaderMask(
      shaderCallback: (Rect bounds) {
        return LinearGradient(
          colors: [startColor, endColor],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ).createShader(bounds);
      },
      child: Text(
        'Hello, $firstName!',
        style: GoogleFonts.poppins(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.white),
      ),
    );
  }

  /// 📌 **Category Cards for Analytics**
  Widget _buildCategoryCard(String title, IconData icon, String route, Color startColor, Color endColor, Color cardColor, Color textColor, bool isDarkMode) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, route),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeInOut,
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(15),
          boxShadow: isDarkMode
              ? []
              : [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              spreadRadius: 2,
              blurRadius: 6,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 35, color: startColor),
            const SizedBox(height: 10),
            Text(title, textAlign: TextAlign.center, style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w500, color: textColor)),
          ],
        ),
      ),
    );
  }
}
