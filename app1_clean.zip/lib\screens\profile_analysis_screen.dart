import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'analysis_result_screen.dart';

class ProfileAnalysisScreen extends StatefulWidget {
  const ProfileAnalysisScreen({super.key});

  @override
  _ProfileAnalysisScreenState createState() => _ProfileAnalysisScreenState();
}

class _ProfileAnalysisScreenState extends State<ProfileAnalysisScreen> {
  bool isLoading = false;
  String analysisResult = '';
  String username = '';
  String password = '';

  Future<void> analyzeProfile({required bool isPrivate}) async {
    username = '';
    password = '';

    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.black,
        title: Center(
          child: Text(
            isPrivate ? "Enter Private Profile Credentials" : "Enter Public Profile Username",
            style: GoogleFonts.poppins(color: Colors.white),
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              onChanged: (value) => username = value,
              decoration: InputDecoration(
                labelText: "Username",
                labelStyle: const TextStyle(color: Colors.white70),
                filled: true,
                fillColor: Colors.grey[850],
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide.none),
              ),
              style: const TextStyle(color: Colors.white),
            ),
            if (isPrivate)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: TextField(
                  onChanged: (value) => password = value,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: "Password",
                    labelStyle: const TextStyle(color: Colors.white70),
                    filled: true,
                    fillColor: Colors.grey[850],
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide.none),
                  ),
                  style: const TextStyle(color: Colors.white),
                ),
              ),
          ],
        ),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text("Cancel", style: GoogleFonts.poppins(color: Colors.white)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              fetchAnalysis(isPrivate: isPrivate);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: Colors.black,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
            ),
            child: Text("Analyze", style: GoogleFonts.poppins()),
          ),
        ],
      ),
    );
  }

  Future<void> fetchAnalysis({required bool isPrivate}) async {
    if (username.trim().isEmpty || (isPrivate && password.trim().isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Please enter all required fields", style: GoogleFonts.poppins()),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() {
      isLoading = true;
      analysisResult = '';
    });

    final url = Uri.parse(
      isPrivate
          ? 'http://127.0.0.1:5000/analyze/private'
          : 'http://127.0.0.1:5000/analyze/profile',
    );

    final requestBody = isPrivate
        ? {
      'username': username,
      'password': password,
    }
        : {
      'type': 'Public',
      'login_id': username,
      'mode': 'caption',
    };

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(requestBody),
      );

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        final profile = responseData['profile'];
        final posts = profile['posts'];

        if (!mounted) return;
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => AnalysisResultScreen(
              name: profile['username'],
              profilePicUrl: profile['profile_pic_url'],
              sentiments: _calculateSentimentStats(posts),
              recentPosts: List<Map<String, dynamic>>.from(posts),
            ),
          ),
        );
      } else {
        setState(() {
          analysisResult = 'Error: ${response.statusCode}';
        });
      }
    } catch (e) {
      setState(() {
        analysisResult = 'An error occurred. Please check your connection and try again.';
      });
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  Map<String, double> _calculateSentimentStats(List posts) {
    int positive = 0, neutral = 0, negative = 0;

    for (var post in posts) {
      final label = post['sentiment'];
      if (label == 'Positive') positive++;
      else if (label == 'Negative') negative++;
      else neutral++;
    }

    final total = posts.length;
    return {
      'Positive': positive / total,
      'Neutral': neutral / total,
      'Negative': negative / total,
    };
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Center(child: Text("Profile Analysis", style: GoogleFonts.poppins(color: Colors.white))),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Analyze Instagram Profile",
                style: GoogleFonts.poppins(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                "Choose an option to analyze a public or private Instagram profile's sentiment.",
                style: GoogleFonts.poppins(fontSize: 14, color: Colors.white70),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () => analyzeProfile(isPrivate: true),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                ),
                child: Text("Analyze Private Profile", style: GoogleFonts.poppins(fontSize: 16)),
              ),
              const SizedBox(height: 15),
              ElevatedButton(
                onPressed: () => analyzeProfile(isPrivate: false),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                ),
                child: Text("Analyze Public Profile", style: GoogleFonts.poppins(fontSize: 16)),
              ),
              const SizedBox(height: 20),
              if (isLoading) const CircularProgressIndicator(color: Colors.white),
              if (!isLoading && analysisResult.isNotEmpty)
                Card(
                  color: Colors.redAccent.withOpacity(0.2),
                  margin: const EdgeInsets.all(16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Text(
                      analysisResult,
                      style: GoogleFonts.poppins(color: Colors.red, fontSize: 15),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
