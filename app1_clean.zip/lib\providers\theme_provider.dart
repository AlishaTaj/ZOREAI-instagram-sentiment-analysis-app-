import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeProvider extends ChangeNotifier {
  ThemeMode _themeMode;
  SharedPreferences? _prefs; // ✅ Nullable to avoid uninitialized access

  ThemeMode get themeMode => _themeMode;

  // ✅ Accept initialDarkMode in constructor
  ThemeProvider({required bool initialDarkMode}) : _themeMode = initialDarkMode ? ThemeMode.dark : ThemeMode.light {
    _initializePreferences(); // ✅ Load preferences in the background
  }

  // ✅ Initialize preferences and load the theme
  Future<void> _initializePreferences() async {
    _prefs = await SharedPreferences.getInstance();
    _loadTheme(); // ✅ Load saved theme after initialization
  }

  // ✅ Toggle theme and update preferences
  void toggleTheme(bool isDarkMode) async {
    _themeMode = isDarkMode ? ThemeMode.dark : ThemeMode.light;
    notifyListeners();
    if (_prefs != null) {
      await _prefs!.setBool('isDarkMode', isDarkMode); // ✅ Save theme state
    }
  }

  // ✅ Load theme from SharedPreferences if available
  void _loadTheme() {
    if (_prefs != null) {
      bool isDarkMode = _prefs!.getBool('isDarkMode') ?? false;
      _themeMode = isDarkMode ? ThemeMode.dark : ThemeMode.light;
      notifyListeners();
    }
  }
}
