// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:provider/provider.dart';
// import '../providers/theme_provider.dart';
//
// class ExploreScreen extends StatefulWidget {
//   final String? section; // ✅ Accepts an optional section parameter
//
//   const ExploreScreen({Key? key, this.section}) : super(key: key);
//
//   @override
//   _ExploreScreenState createState() => _ExploreScreenState();
// }
//
// class _ExploreScreenState extends State<ExploreScreen> {
//   final TextEditingController _searchController = TextEditingController();
//
//   /// ✅ Mock Trending Data (With Fixes)
//   final List<Map<String, dynamic>> trendingTopics = [
//     {"title": "Top Influencers", "subtitle": "Discover leading influencers.", "icon": Icons.person, "route": "/influencer-analysis"},
//     {"title": "Viral Hashtags", "subtitle": "Explore the hottest hashtags.", "icon": Icons.tag, "route": "/hashtag-analysis"},
//     {"title": "Top Brands", "subtitle": "Track leading brands.", "icon": Icons.business, "route": "/brand-analysis"},
//     {"title": "Trending Posts", "subtitle": "See what's getting the most engagement.", "icon": Icons.trending_up, "route": "/trending-posts"},
//     {"title": "Upcoming Events", "subtitle": "Stay updated on industry events.", "icon": Icons.event, "route": "/upcoming-events"},
//     {"title": "New Creators", "subtitle": "Check out rising stars in social media.", "icon": Icons.new_releases, "route": "/new-creators"},
//   ];
//
//   @override
//   Widget build(BuildContext context) {
//     final themeProvider = Provider.of<ThemeProvider>(context);
//     final isDarkMode = themeProvider.themeMode == ThemeMode.dark;
//
//     return Scaffold(
//       backgroundColor: Theme.of(context).scaffoldBackgroundColor,
//       appBar: AppBar(
//         title: Text(
//           widget.section == null ? "Explore" : _getSectionTitle(widget.section!),
//           style: GoogleFonts.poppins(
//             fontSize: 18,
//             fontWeight: FontWeight.bold,
//             color: Theme.of(context).textTheme.bodyLarge?.color ?? Colors.white,
//           ),
//         ),
//         backgroundColor: Colors.transparent,
//         elevation: 0,
//         iconTheme: IconThemeData(
//           color: Theme.of(context).iconTheme.color ?? Colors.white,
//         ),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             if (widget.section == null) ...[
//               TextField(
//                 controller: _searchController,
//                 decoration: InputDecoration(
//                   filled: true,
//                   fillColor: isDarkMode ? Colors.grey[900] : Colors.grey[200],
//                   hintText: "Search influencers, brands, hashtags...",
//                   hintStyle: GoogleFonts.poppins(color: isDarkMode ? Colors.white70 : Colors.black54),
//                   prefixIcon: Icon(Icons.search, color: isDarkMode ? Colors.white70 : Colors.black54),
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(12),
//                     borderSide: BorderSide.none,
//                   ),
//                 ),
//                 style: GoogleFonts.poppins(fontSize: 14, color: Theme.of(context).textTheme.bodyLarge?.color),
//               ),
//               const SizedBox(height: 20),
//               Text(
//                 "Trending Now 🔥",
//                 style: GoogleFonts.poppins(
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                   color: Theme.of(context).textTheme.bodyLarge?.color,
//                 ),
//               ),
//               const SizedBox(height: 10),
//             ],
//             Expanded(
//               child: ListView.separated(
//                 itemCount: widget.section == null
//                     ? trendingTopics.length
//                     : trendingTopics.where((item) => item["route"] == "/${widget.section}").length,
//                 separatorBuilder: (context, index) => const SizedBox(height: 10),
//                 itemBuilder: (context, index) {
//                   var filteredList = widget.section == null
//                       ? trendingTopics
//                       : trendingTopics.where((item) => item["route"] == "/${widget.section}").toList();
//                   var item = filteredList[index];
//                   return _buildTrendingCard(item["title"], item["subtitle"], item["icon"], item["route"], isDarkMode);
//                 },
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   String _getSectionTitle(String section) {
//     switch (section) {
//       case "trending-posts":
//         return "Trending Posts";
//       case "upcoming-events":
//         return "Upcoming Events";
//       case "new-creators":
//         return "New Creators";
//       default:
//         return "Explore";
//     }
//   }
//
//   Widget _buildTrendingCard(String title, String subtitle, IconData icon, String route, bool isDarkMode) {
//     return GestureDetector(
//       onTap: () => Navigator.pushNamed(context, route),
//       child: Card(
//         margin: const EdgeInsets.only(bottom: 8),
//         elevation: isDarkMode ? 0 : 2,
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//         color: isDarkMode ? Colors.grey[850] : Color(0xFFF3E5F5),
//         child: ListTile(
//           leading: ShaderMask(
//             shaderCallback: (bounds) => LinearGradient(
//               colors: [Colors.deepPurple, Colors.purpleAccent],
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//             ).createShader(bounds),
//             child: Icon(icon, color: Colors.white),
//           ),
//           title: Text(
//             title,
//             style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.bold, color: isDarkMode ? Colors.white : Colors.black),
//           ),
//           subtitle: Text(
//             subtitle,
//             style: GoogleFonts.poppins(fontSize: 13, color: isDarkMode ? Colors.white70 : Colors.black87),
//           ),
//           trailing: Icon(Icons.arrow_forward_ios, size: 16, color: isDarkMode ? Colors.white70 : Colors.black54),
//         ),
//       ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';

class ExploreScreen extends StatefulWidget {
  final String? section;

  const ExploreScreen({Key? key, this.section}) : super(key: key);

  @override
  _ExploreScreenState createState() => _ExploreScreenState();
}

class _ExploreScreenState extends State<ExploreScreen> {
  final TextEditingController _searchController = TextEditingController();

  /// Mock Trending Data
  final List<Map<String, dynamic>> trendingTopics = [
    {"title": "Top Influencers", "subtitle": "Discover leading influencers.", "icon": Icons.person, "route": "/influencer-analysis"},
    {"title": "Viral Hashtags", "subtitle": "Explore the hottest hashtags.", "icon": Icons.tag, "route": "/hashtag-analysis"},
    {"title": "Top Brands", "subtitle": "Track leading brands.", "icon": Icons.business, "route": "/brand-analysis"},
    {"title": "Trending Posts", "subtitle": "See what's getting the most engagement.", "icon": Icons.trending_up, "route": "/trending-posts"},
    {"title": "Upcoming Events", "subtitle": "Stay updated on industry events.", "icon": Icons.event, "route": "/upcoming-events"},
    {"title": "New Creators", "subtitle": "Check out rising stars in social media.", "icon": Icons.new_releases, "route": "/new-creators"},
  ];

  /// Returns filtered list based on search and section
  List<Map<String, dynamic>> get _filteredTrendingTopics {
    List<Map<String, dynamic>> list = widget.section == null
        ? trendingTopics
        : trendingTopics.where((item) => item["route"] == "/${widget.section}").toList();

    if (_searchController.text.isEmpty) return list;

    return list.where((item) =>
        item["title"].toLowerCase().contains(_searchController.text.toLowerCase())).toList();
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final isDarkMode = themeProvider.themeMode == ThemeMode.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          widget.section == null ? "Explore" : _getSectionTitle(widget.section!),
          style: GoogleFonts.poppins(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Theme.of(context).textTheme.bodyLarge?.color ?? Colors.white,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(
          color: Theme.of(context).iconTheme.color ?? Colors.white,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (widget.section == null) ...[
              TextField(
                controller: _searchController,
                onChanged: (_) => setState(() {}),
                decoration: InputDecoration(
                  filled: true,
                  fillColor: isDarkMode ? Colors.grey[900] : Colors.grey[200],
                  hintText: "Search influencers, brands, hashtags...",
                  hintStyle: GoogleFonts.poppins(color: isDarkMode ? Colors.white70 : Colors.black54),
                  prefixIcon: Icon(Icons.search, color: isDarkMode ? Colors.white70 : Colors.black54),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                ),
                style: GoogleFonts.poppins(fontSize: 14, color: Theme.of(context).textTheme.bodyLarge?.color),
              ),
              const SizedBox(height: 20),
              Text(
                "Trending Now 🔥",
                style: GoogleFonts.poppins(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).textTheme.bodyLarge?.color,
                ),
              ),
              const SizedBox(height: 10),
            ],
            Expanded(
              child: _filteredTrendingTopics.isEmpty
                  ? Center(
                child: Text(
                  "No results found.",
                  style: GoogleFonts.poppins(color: Theme.of(context).textTheme.bodyLarge?.color),
                ),
              )
                  : ListView.separated(
                itemCount: _filteredTrendingTopics.length,
                separatorBuilder: (context, index) => const SizedBox(height: 10),
                itemBuilder: (context, index) {
                  var item = _filteredTrendingTopics[index];
                  return _buildTrendingCard(item["title"], item["subtitle"], item["icon"], item["route"], isDarkMode);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Converts route slug to readable title
  String _getSectionTitle(String section) {
    switch (section) {
      case "trending-posts":
        return "Trending Posts";
      case "upcoming-events":
        return "Upcoming Events";
      case "new-creators":
        return "New Creators";
      default:
        return "Explore";
    }
  }

  /// Reusable Trending Card
  Widget _buildTrendingCard(String title, String subtitle, IconData icon, String route, bool isDarkMode) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, route),
      child: Card(
        margin: const EdgeInsets.only(bottom: 8),
        elevation: isDarkMode ? 0 : 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        color: isDarkMode ? Colors.grey[850] : const Color(0xFFF3E5F5),
        child: ListTile(
          leading: ShaderMask(
            shaderCallback: (bounds) => const LinearGradient(
              colors: [Colors.deepPurple, Colors.purpleAccent],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ).createShader(bounds),
            child: Icon(icon, color: Colors.white),
          ),
          title: Text(
            title,
            style: GoogleFonts.poppins(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: isDarkMode ? Colors.white : Colors.black,
            ),
          ),
          subtitle: Text(
            subtitle,
            style: GoogleFonts.poppins(
              fontSize: 13,
              color: isDarkMode ? Colors.white70 : Colors.black87,
            ),
          ),
          trailing: Icon(Icons.arrow_forward_ios, size: 16, color: isDarkMode ? Colors.white70 : Colors.black54),
        ),
      ),
    );
  }
}
