// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:fl_chart/fl_chart.dart';
//
// class SentimentScreen extends StatelessWidget {
//   const SentimentScreen({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Sentiment", style: GoogleFonts.poppins(color: Colors.white)),
//         backgroundColor: Colors.black,
//         iconTheme: IconThemeData(color: Colors.white),
//       ),
//       backgroundColor: Colors.black,
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.stretch,
//           children: [
//             Text(
//               "Sentiment Trends and Highlights",
//               style: GoogleFonts.poppins(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold),
//               textAlign: TextAlign.center,
//             ),
//             SizedBox(height: 20),
//             _buildSentimentOverviewCard(),
//             SizedBox(height: 20),
//             _buildSentimentChart(),
//             SizedBox(height: 20),
//             _buildSentimentHighlights(),
//           ],
//         ),
//       ),
//     );
//   }
//
//   // Sentiment Overview Card
//   Widget _buildSentimentOverviewCard() {
//     return Card(
//       color: Colors.white12,
//       shape: RoundedRectangleBorder(
//         borderRadius: BorderRadius.circular(10),
//       ),
//       child: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text(
//               "Sentiment Overview",
//               style: GoogleFonts.poppins(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
//             ),
//             SizedBox(height: 10),
//             _buildSentimentRow("Positive", "70%", Colors.greenAccent),
//             _buildSentimentRow("Neutral", "20%", Colors.yellow),
//             _buildSentimentRow("Negative", "10%", Colors.red),
//           ],
//         ),
//       ),
//     );
//   }
//
//   // Reusable Sentiment Row Widget
//   Widget _buildSentimentRow(String label, String value, Color color) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 4.0),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
//           Text(label, style: GoogleFonts.poppins(color: Colors.white70)),
//           Text(value, style: GoogleFonts.poppins(color: color)),
//         ],
//       ),
//     );
//   }
//
//   // Sentiment Chart Placeholder
//   Widget _buildSentimentChart() {
//     return Card(
//       color: Colors.white12,
//       shape: RoundedRectangleBorder(
//         borderRadius: BorderRadius.circular(10),
//       ),
//       child: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text(
//               "Sentiment Trend Over Time",
//               style: GoogleFonts.poppins(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
//             ),
//             SizedBox(height: 20),
//             AspectRatio(
//               aspectRatio: 1.7,
//               child: LineChart(
//                 LineChartData(
//                   gridData: FlGridData(show: true, drawVerticalLine: true),
//                   borderData: FlBorderData(show: true),
//                   titlesData: FlTitlesData(show: false),
//                   lineBarsData: [
//                     LineChartBarData(
//                       spots: [
//                         FlSpot(0, 20),
//                         FlSpot(1, 50),
//                         FlSpot(2, 30),
//                         FlSpot(3, 80),
//                         FlSpot(4, 60),
//                       ],
//                       isCurved: true,
//                       colors: [Colors.greenAccent, Colors.lightGreen], // ✅ Fixed: Replaced gradient with colors
//                       barWidth: 2,
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   // Sentiment Highlights Placeholder
//   Widget _buildSentimentHighlights() {
//     return Card(
//       color: Colors.white12,
//       shape: RoundedRectangleBorder(
//         borderRadius: BorderRadius.circular(10),
//       ),
//       child: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text(
//               "Sentiment Highlights",
//               style: GoogleFonts.poppins(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
//             ),
//             SizedBox(height: 10),
//             _buildHighlight("Positive Feedback", "Increased by 15% last week"),
//             _buildHighlight("Negative Feedback", "Decreased by 5% this month"),
//             _buildHighlight("Neutral Feedback", "Remained stable"),
//           ],
//         ),
//       ),
//     );
//   }
//
//   // Reusable Highlight Row
//   Widget _buildHighlight(String title, String description) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 4.0),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
//           Text(title, style: GoogleFonts.poppins(color: Colors.white70)),
//           Text(description, style: GoogleFonts.poppins(color: Colors.white)),
//         ],
//       ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class SentimentScreen extends StatefulWidget {
  const SentimentScreen({super.key});

  @override
  _SentimentScreenState createState() => _SentimentScreenState();
}

class _SentimentScreenState extends State<SentimentScreen> {
  late Future<Map<String, dynamic>> sentimentFuture;

  @override
  void initState() {
    super.initState();
    sentimentFuture = fetchSentimentData();
  }

  Future<Map<String, dynamic>> fetchSentimentData() async {
    final response = await http.get(Uri.parse('http://127.0.0.1:5000/sentiment_trend'));
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to load sentiment data');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Sentiment", style: GoogleFonts.poppins(color: Colors.white)),
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      backgroundColor: Colors.black,
      body: FutureBuilder<Map<String, dynamic>>(
        future: sentimentFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: Colors.white));
          } else if (snapshot.hasError) {
            return Center(child: Text("Error loading data", style: GoogleFonts.poppins(color: Colors.redAccent)));
          } else {
            final data = snapshot.data!;
            return _buildContent(data);
          }
        },
      ),
    );
  }

  Widget _buildContent(Map<String, dynamic> data) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            "Sentiment Trends and Highlights",
            style: GoogleFonts.poppins(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          _buildSentimentOverviewCard(data),
          const SizedBox(height: 20),
          _buildSentimentChart(List<double>.from(data['trend'])),
          const SizedBox(height: 20),
          _buildSentimentHighlights(List<Map<String, dynamic>>.from(data['highlights'])),
        ],
      ),
    );
  }

  Widget _buildSentimentOverviewCard(Map<String, dynamic> data) {
    return Card(
      color: Colors.white12,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Sentiment Overview", style: GoogleFonts.poppins(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            _buildSentimentRow("Positive", "${data['positive']}%", Colors.greenAccent),
            _buildSentimentRow("Neutral", "${data['neutral']}%", Colors.yellow),
            _buildSentimentRow("Negative", "${data['negative']}%", Colors.red),
          ],
        ),
      ),
    );
  }

  Widget _buildSentimentRow(String label, String value, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: GoogleFonts.poppins(color: Colors.white70)),
          Text(value, style: GoogleFonts.poppins(color: color)),
        ],
      ),
    );
  }

  Widget _buildSentimentChart(List<double> trendData) {
    return Card(
      color: Colors.white12,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Sentiment Trend Over Time", style: GoogleFonts.poppins(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            AspectRatio(
              aspectRatio: 1.7,
              child: LineChart(
                LineChartData(
                  gridData: FlGridData(show: true, drawVerticalLine: true),
                  borderData: FlBorderData(show: true),
                  titlesData: FlTitlesData(show: false),
                  lineBarsData: [
                    LineChartBarData(
                      spots: trendData.asMap().entries.map((e) => FlSpot(e.key.toDouble(), e.value)).toList(),
                      isCurved: true,
                      colors: [Colors.greenAccent],
                      barWidth: 2,
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSentimentHighlights(List<Map<String, dynamic>> highlights) {
    return Card(
      color: Colors.white12,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Sentiment Highlights", style: GoogleFonts.poppins(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ...highlights.map((item) => _buildHighlight(item['title'], item['desc'])).toList(),
          ],
        ),
      ),
    );
  }

  Widget _buildHighlight(String title, String description) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: GoogleFonts.poppins(color: Colors.white70)),
          Text(description, style: GoogleFonts.poppins(color: Colors.white)),
        ],
      ),
    );
  }
}
