import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

class BrandAnalysisScreen extends StatefulWidget {
  final String brandUsername;
  const BrandAnalysisScreen({super.key, required this.brandUsername});

  @override
  _BrandAnalysisScreenState createState() => _BrandAnalysisScreenState();
}

class _BrandAnalysisScreenState extends State<BrandAnalysisScreen> {
  Map<String, dynamic>? brandData;
  bool isLoading = false;
  final backendUrl = "http://127.0.0.1:5000";

  @override
  void initState() {
    super.initState();
    fetchBrandMetrics(widget.brandUsername);
  }

  Future<void> fetchBrandMetrics(String brandName) async {
    setState(() => isLoading = true);
    try {
      print("🔍 Sending brand_username: $brandName");
      final response = await http.post(
        Uri.parse("$backendUrl/analyze/brand"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"brand_username": brandName}),
      );
      print("🟢 Response Code: ${response.statusCode}");
      print("📦 Response Body: ${response.body}");

      if (response.statusCode == 200) {
        setState(() {
          brandData = jsonDecode(response.body);
          isLoading = false;
        });
      } else {
        throw Exception("Failed to load brand data");
      }
    } catch (e) {
      setState(() {
        brandData = {"error": e.toString()};
        isLoading = false;
      });
    }
  }

  Future<void> downloadPDF() async {
    final pdfUrl = "$backendUrl/analyze/brand/pdf/${widget.brandUsername}";
    if (await canLaunchUrl(Uri.parse(pdfUrl))) {
      await launchUrl(Uri.parse(pdfUrl), mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Could not open PDF link.")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Brand Analysis', style: GoogleFonts.poppins(color: Colors.white)),
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            onPressed: () => fetchBrandMetrics(widget.brandUsername),
            icon: const Icon(Icons.refresh),
          )
        ],
      ),
      backgroundColor: Colors.black,
      body: isLoading
          ? const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: Colors.white),
            SizedBox(height: 12),
            Text("Fetching brand data...", style: TextStyle(color: Colors.white)),
          ],
        ),
      )
          : brandData == null
          ? const Center(child: Text("No data found", style: TextStyle(color: Colors.white)))
          : brandData!['error'] != null
          ? Center(child: Text(brandData!['error'], style: const TextStyle(color: Colors.red)))
          : ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            widget.brandUsername.toUpperCase(),
            style: GoogleFonts.poppins(
                color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          _buildMetricCard('Followers', brandData!['followers'].toString()),
          _buildMetricCard('Engagement Rate', '${brandData!['engagement_rate']}%'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4.0),
            child: Text(
              "ℹ Engagement Rate = % of followers who engage with posts (likes/comments)",
              style: GoogleFonts.poppins(color: Colors.white70, fontSize: 11),
            ),
          ),
          const SizedBox(height: 10),
          _buildMetricCard('Avg Likes', brandData!['avg_likes'].toString()),
          _buildMetricCard('Avg Comments', brandData!['avg_comments'].toString()),
          const SizedBox(height: 10),
          _buildSentimentIndicator(brandData!['sentiment_score']),
          const SizedBox(height: 10),
          _buildTrendChart(List<double>.from(brandData!['trendline'])),
          const SizedBox(height: 8),
          Text(
            "📈 Trendline shows engagement trend over time (recent posts).",
            style: GoogleFonts.poppins(color: Colors.white70, fontSize: 11),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 10),
          _buildPRRiskBadge(brandData!['pr_risk']),
          const SizedBox(height: 20),
          _buildGPTSummary(brandData!['gpt_summary']),
          const SizedBox(height: 20),
          _buildExportPDFButton(),
        ],
      ),
    );
  }

  Widget _buildMetricCard(String title, String value) {
    return Card(
      color: Colors.white12,
      margin: const EdgeInsets.symmetric(vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
      child: ListTile(
        title: Text(title, style: GoogleFonts.poppins(color: Colors.white)),
        trailing: Text(value, style: GoogleFonts.poppins(color: Colors.white)),
      ),
    );
  }

  Widget _buildSentimentIndicator(double score) {
    String emoji;
    Color color;

    if (score >= 75) {
      emoji = "😄";
      color = Colors.green;
    } else if (score >= 50) {
      emoji = "😐";
      color = Colors.orange;
    } else {
      emoji = "😡";
      color = Colors.red;
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text("Sentiment", style: GoogleFonts.poppins(color: Colors.white)),
        Text(emoji, style: const TextStyle(fontSize: 40)),
        Text("${score.toStringAsFixed(1)}%", style: GoogleFonts.poppins(color: color)),
      ],
    );
  }

  Widget _buildTrendChart(List<double> trendData) {
    return SizedBox(
      height: 180,
      child: LineChart(
        LineChartData(
          titlesData: FlTitlesData(show: false),
          borderData: FlBorderData(show: false),
          lineBarsData: [
            LineChartBarData(
              isCurved: true,
              barWidth: 3,
              colors: [Colors.cyanAccent],
              dotData: FlDotData(show: false),
              spots: trendData
                  .asMap()
                  .entries
                  .map((e) => FlSpot(e.key.toDouble(), e.value))
                  .toList(),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildPRRiskBadge(bool risk) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: risk ? Colors.red : Colors.green,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        risk ? "⚠️ PR Risk Detected" : "✅ Healthy Reputation",
        style: GoogleFonts.poppins(color: Colors.white),
        textAlign: TextAlign.center,
      ),
    );
  }

  Widget _buildGPTSummary(String? summary) {
    return Card(
      color: Colors.white12,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Text(
          summary != null && summary.isNotEmpty
              ? summary
              : "GPT summary generation failed.",
          style: GoogleFonts.poppins(color: Colors.white70),
        ),
      ),
    );
  }

  Widget _buildExportPDFButton() {
    return ElevatedButton.icon(
      onPressed: downloadPDF,
      icon: const Icon(Icons.picture_as_pdf),
      label: const Text("Export PDF"),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        padding: const EdgeInsets.symmetric(vertical: 14),
      ),
    );
  }
}
