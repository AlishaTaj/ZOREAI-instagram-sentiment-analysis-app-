// lib/models/profile.dart

class Profile {
  final String username;
  final String bio;
  final int followers;
  final int following;
  final int posts;
  final bool isPrivate;

  Profile({
    required this.username,
    required this.bio,
    required this.followers,
    required this.following,
    required this.posts,
    required this.isPrivate,
  });

  // Add a factory method if you need to create a Profile instance from JSON.
  factory Profile.fromJson(Map<String, dynamic> json) {
    return Profile(
      username: json['username'] ?? '',
      bio: json['bio'] ?? '',
      followers: json['followers'] ?? 0,
      following: json['following'] ?? 0,
      posts: json['posts'] ?? 0,
      isPrivate: json['is_private'] ?? false,
    );
  }
}