import 'package:flutter/material.dart';

class AuthForm extends StatelessWidget {
  final bool isLogin;
  final VoidCallback onSubmit;

  const AuthForm({super.key, required this.isLogin, required this.onSubmit});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TextFormField(
          decoration: const InputDecoration(labelText: 'Email'),
        ),
        const SizedBox(height: 10),
        TextFormField(
          decoration: const InputDecoration(labelText: 'Password'),
          obscureText: true,
        ),
        if (!isLogin)
          const SizedBox(height: 10),
        if (!isLogin)
          TextFormField(
            decoration: const InputDecoration(labelText: 'Confirm Password'),
            obscureText: true,
          ),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: onSubmit,
          child: Text(isLogin ? 'Login' : 'Sign Up'),
        ),
      ],
    );
  }
}