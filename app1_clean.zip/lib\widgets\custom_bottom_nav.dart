import 'package:flutter/material.dart';
import 'package:salomon_bottom_bar/salomon_bottom_bar.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';

class CustomBottomNav extends StatefulWidget {
  @override
  _CustomBottomNavState createState() => _CustomBottomNavState();
}

class _CustomBottomNavState extends State<CustomBottomNav> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final isDarkMode = themeProvider.themeMode == ThemeMode.dark;

    return SalomonBottomBar(
      currentIndex: _currentIndex,
      onTap: (i) => setState(() => _currentIndex = i),
      items: [
        SalomonBottomBarItem(
          icon: Icon(Icons.home),
          title: Text("Home"),
          selectedColor: isDarkMode ? Colors.white : Colors.black,
        ),
        SalomonBottomBarItem(
          icon: Icon(Icons.calendar_today),
          title: Text("Calendar"),
          selectedColor: isDarkMode ? Colors.white : Colors.black,
        ),
        SalomonBottomBarItem(
          icon: Icon(Icons.shield),
          title: Text("Reports"),
          selectedColor: isDarkMode ? Colors.white : Colors.black,
        ),
        SalomonBottomBarItem(
          icon: Icon(Icons.message),
          title: Text("Messages"),
          selectedColor: isDarkMode ? Colors.white : Colors.black,
        ),
      ],
    );
  }
}