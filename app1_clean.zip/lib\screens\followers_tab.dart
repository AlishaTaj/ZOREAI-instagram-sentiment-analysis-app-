// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
//
// class FollowersScreen extends StatefulWidget {
//   const FollowersScreen({super.key});
//
//   @override
//   _FollowersScreenState createState() => _FollowersScreenState();
// }
//
// class _FollowersScreenState extends State<FollowersScreen> {
//   bool isLoading = true;
//   List<Map<String, String>> followerData = [
//     {"location": "New York, USA", "count": "1200"},
//     {"location": "London, UK", "count": "900"},
//     {"location": "Tokyo, Japan", "count": "750"},
//     {"location": "Sydney, Australia", "count": "600"},
//   ];
//
//   @override
//   void initState() {
//     super.initState();
//     _fetchFollowerData();
//   }
//
//   Future<void> _fetchFollowerData() async {
//     await Future.delayed(Duration(seconds: 2)); // Simulate data fetching delay
//     setState(() {
//       isLoading = false;
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text(
//           "Follower Demographics",
//           style: GoogleFonts.poppins(color: Colors.white),
//         ),
//         backgroundColor: Colors.black,
//         iconTheme: IconThemeData(color: Colors.white),
//       ),
//       backgroundColor: Colors.black,
//       body: isLoading
//           ? Center(
//         child: CircularProgressIndicator(color: Colors.white),
//       )
//           : Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: ListView.builder(
//           itemCount: followerData.length,
//           itemBuilder: (context, index) {
//             return Card(
//               color: Colors.white12,
//               shape: RoundedRectangleBorder(
//                 borderRadius: BorderRadius.circular(10),
//               ),
//               margin: EdgeInsets.symmetric(vertical: 8),
//               child: ListTile(
//                 leading: Icon(
//                   Icons.location_on,
//                   color: Colors.white70,
//                 ),
//                 title: Text(
//                   followerData[index]['location'] ?? '',
//                   style: GoogleFonts.poppins(
//                     color: Colors.white,
//                     fontWeight: FontWeight.bold,
//                   ),
//                 ),
//                 trailing: Text(
//                   followerData[index]['count'] ?? '',
//                   style: GoogleFonts.poppins(
//                     color: Colors.white70,
//                     fontSize: 16,
//                   ),
//                 ),
//               ),
//             );
//           },
//         ),
//       ),
//     );
//   }
// }



import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class FollowersScreen extends StatefulWidget {
  const FollowersScreen({super.key});

  @override
  _FollowersScreenState createState() => _FollowersScreenState();
}

class _FollowersScreenState extends State<FollowersScreen> {
  bool isLoading = true;
  List<Map<String, String>> followerData = [];

  @override
  void initState() {
    super.initState();
    _fetchFollowerData();
  }

  Future<void> _fetchFollowerData() async {
    await Future.delayed(const Duration(seconds: 2)); // Simulate backend fetch
    setState(() {
      followerData = [
        {"location": "New York, USA", "count": "1200"},
        {"location": "London, UK", "count": "900"},
        {"location": "Tokyo, Japan", "count": "750"},
        {"location": "Sydney, Australia", "count": "600"},
      ];
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Follower Demographics", style: GoogleFonts.poppins(color: Colors.white)),
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      backgroundColor: Colors.black,
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: Colors.white))
          : followerData.isEmpty
          ? Center(
        child: Text(
          "No follower data found",
          style: GoogleFonts.poppins(color: Colors.white70),
        ),
      )
          : Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView.builder(
          itemCount: followerData.length,
          itemBuilder: (context, index) {
            return Card(
              color: Colors.white12,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: ListTile(
                leading: const Icon(Icons.location_on, color: Colors.white70),
                title: Text(
                  followerData[index]['location'] ?? '',
                  style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                trailing: Text(
                  followerData[index]['count'] ?? '',
                  style: GoogleFonts.poppins(color: Colors.white70, fontSize: 16),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
