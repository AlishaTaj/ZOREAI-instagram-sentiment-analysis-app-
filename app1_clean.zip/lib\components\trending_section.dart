// 📁 components/trending_section.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class TrendingSection extends StatelessWidget {
  const TrendingSection({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Trending Hashtags', style: GoogleFonts.poppins(fontSize: 18, color: Colors.grey[400])),
        SizedBox(height: 10),
        SizedBox(
          height: 150,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              _buildTrendCard('#GrowthHacks', 80),
              _buildTrendCard('#InstaSuccess', 70),
              _buildTrendCard('#MarketingTips', 60),
              _buildTrendCard('#ViralContent', 90),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTrendCard(String hashtag, int popularity) {
    return Card(
      color: Colors.grey[900],
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Container(
        width: 120,
        padding: const EdgeInsets.all(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(hashtag, style: GoogleFonts.poppins(fontSize: 14, color: Colors.white)),
            SizedBox(height: 8),
            LinearProgressIndicator(value: popularity / 100, color: Colors.teal, backgroundColor: Colors.grey[800]),
            SizedBox(height: 4),
            Text('$popularity%', style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey[400])),
          ],
        ),
      ),
    );
  }
}