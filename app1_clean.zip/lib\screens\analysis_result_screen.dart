import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:convert';

class AnalysisResultScreen extends StatelessWidget {
  final String name;
  final String profilePicUrl;
  final Map<String, double> sentiments;
  final List<Map<String, dynamic>> recentPosts;

  const AnalysisResultScreen({
    super.key,
    required this.name,
    required this.profilePicUrl,
    required this.sentiments,
    required this.recentPosts,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(
          'Analysis Result',
          style: GoogleFonts.poppins(color: Colors.white),
        ),
      ),
      backgroundColor: Colors.black,
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: profilePicUrl.startsWith('data:image')
                  ? CircleAvatar(
                radius: 40,
                backgroundImage: MemoryImage(
                  base64Decode(profilePicUrl.split(',')[1]),
                ),
              )
                  : CircleAvatar(
                radius: 40,
                backgroundImage: NetworkImage(profilePicUrl),
                onBackgroundImageError: (_, __) => Icon(Icons.error, color: Colors.red),
              ),
            ),
            const SizedBox(height: 10),
            Center(
              child: Text(
                name,
                style: GoogleFonts.poppins(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'Sentiment Analysis',
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 10),
            for (var entry in sentiments.entries)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 5.0),
                child: Row(
                  children: [
                    Text(
                      '${entry.key}: ',
                      style: GoogleFonts.poppins(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Expanded(
                      child: LinearProgressIndicator(
                        value: entry.value / 100,
                        color: entry.key == 'Positive'
                            ? Colors.green
                            : entry.key == 'Neutral'
                            ? Colors.yellow
                            : Colors.red,
                        backgroundColor: Colors.white24,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      '${entry.value.toStringAsFixed(1)}%',
                      style: GoogleFonts.poppins(color: Colors.white),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 20),
            Text(
              'Recent Posts',
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 10),
            for (var post in recentPosts)
              Card(
                color: Colors.white12,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                margin: EdgeInsets.symmetric(vertical: 5),
                child: ListTile(
                  leading: post['url'] != null && post['url'].startsWith('data:image')
                      ? ClipRRect(
                    borderRadius: BorderRadius.circular(8.0),
                    child: Image.memory(
                      base64Decode(post['url'].split(',')[1]),
                      width: 50,
                      height: 50,
                      fit: BoxFit.cover,
                    ),
                  )
                      : ClipRRect(
                    borderRadius: BorderRadius.circular(8.0),
                    child: Image.network(
                      post['url'] ?? '',
                      width: 50,
                      height: 50,
                      fit: BoxFit.cover,
                      loadingBuilder: (context, child, loadingProgress) {
                        if (loadingProgress == null) return child;
                        return Center(
                          child: CircularProgressIndicator(
                            value: loadingProgress.expectedTotalBytes != null
                                ? loadingProgress.cumulativeBytesLoaded /
                                loadingProgress.expectedTotalBytes!
                                : null,
                            color: Colors.white,
                          ),
                        );
                      },
                      errorBuilder: (context, error, stackTrace) {
                        return Icon(Icons.error, color: Colors.red);
                      },
                    ),
                  ),
                  title: Text(
                    post['date'] ?? '',
                    style: GoogleFonts.poppins(color: Colors.white),
                  ),
                  subtitle: Text(
                    'Likes: ${post['likes'] ?? 'N/A'}',
                    style: GoogleFonts.poppins(color: Colors.white70),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}