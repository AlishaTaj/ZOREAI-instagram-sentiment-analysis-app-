// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
//
// class ContentScreen extends StatefulWidget {
//   const ContentScreen({super.key});
//
//   @override
//   _ContentScreenState createState() => _ContentScreenState();
// }
//
// class _ContentScreenState extends State<ContentScreen> {
//   bool isLoading = true;
//   List<Map<String, dynamic>> contentData = [
//     {"title": "Post 1", "engagement": "120 Likes, 30 Comments"},
//     {"title": "Post 2", "engagement": "150 Likes, 40 Comments"},
//     {"title": "Post 3", "engagement": "200 Likes, 50 Comments"},
//   ];
//
//   @override
//   void initState() {
//     super.initState();
//     _fetchContentData();
//   }
//
//   Future<void> _fetchContentData() async {
//     await Future.delayed(Duration(seconds: 2)); // Simulate data fetching delay
//     setState(() {
//       isLoading = false;
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text(
//           "Content Analysis",
//           style: GoogleFonts.poppins(color: Colors.white),
//         ),
//         backgroundColor: Colors.black,
//         iconTheme: IconThemeData(color: Colors.white),
//       ),
//       backgroundColor: Colors.black,
//       body: isLoading
//           ? Center(
//         child: CircularProgressIndicator(color: Colors.white),
//       )
//           : Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: ListView.builder(
//           itemCount: contentData.length,
//           itemBuilder: (context, index) {
//             return Card(
//               color: Colors.white12,
//               shape: RoundedRectangleBorder(
//                 borderRadius: BorderRadius.circular(10),
//               ),
//               margin: EdgeInsets.symmetric(vertical: 8),
//               child: ListTile(
//                 title: Text(
//                   contentData[index]['title'],
//                   style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold),
//                 ),
//                 subtitle: Text(
//                   contentData[index]['engagement'],
//                   style: GoogleFonts.poppins(color: Colors.white70),
//                 ),
//                 trailing: Icon(Icons.arrow_forward_ios, color: Colors.white70, size: 20),
//               ),
//             );
//           },
//         ),
//       ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ContentScreen extends StatefulWidget {
  const ContentScreen({super.key});

  @override
  _ContentScreenState createState() => _ContentScreenState();
}

class _ContentScreenState extends State<ContentScreen> {
  bool isLoading = false;
  List<Map<String, String>> contentData = [];

  @override
  void initState() {
    super.initState();
    _loadMockContent();
  }

  void _loadMockContent() async {
    setState(() => isLoading = true);
    await Future.delayed(const Duration(seconds: 2)); // Simulate API delay
    setState(() {
      contentData = [
        {"title": "Post 1", "engagement": "120 Likes, 30 Comments"},
        {"title": "Post 2", "engagement": "150 Likes, 40 Comments"},
        {"title": "Post 3", "engagement": "200 Likes, 50 Comments"},
      ];
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Content Analysis",
          style: GoogleFonts.poppins(color: Colors.white),
        ),
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      backgroundColor: Colors.black,
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: Colors.white))
          : Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView.builder(
          itemCount: contentData.length,
          itemBuilder: (context, index) {
            return Card(
              color: Colors.white12,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: ListTile(
                title: Text(
                  contentData[index]['title'] ?? '',
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                subtitle: Text(
                  contentData[index]['engagement'] ?? '',
                  style: GoogleFonts.poppins(color: Colors.white70),
                ),
                trailing: const Icon(Icons.arrow_forward_ios, color: Colors.white70, size: 20),
                onTap: () {
                  // Future: Navigate to post detail
                },
              ),
            );
          },
        ),
      ),
    );
  }
}
