import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

class InfluencerAnalysisScreen extends StatefulWidget {
  const InfluencerAnalysisScreen({super.key});

  @override
  State<InfluencerAnalysisScreen> createState() => _InfluencerAnalysisScreenState();
}

class _InfluencerAnalysisScreenState extends State<InfluencerAnalysisScreen> {
  final TextEditingController _searchController = TextEditingController();
  final String baseUrl = 'http://127.0.0.1:5000/influencers/api';
  bool isLoading = false;

  Future<void> _searchInfluencer(String username) async {
    if (username.trim().isEmpty) return;

    setState(() => isLoading = true);

    try {
      final response = await http.get(Uri.parse('$baseUrl/$username'));
      if (response.statusCode == 200) {
        final Map<String, dynamic> influencer = json.decode(response.body);
        Navigator.pushNamed(
          context,
          '/influencer-profile',
          arguments: influencer,
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Influencer not found")),
        );
      }
    } catch (e) {
      print("Error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Something went wrong")),
      );
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text('Search Influencers', style: GoogleFonts.poppins(color: Colors.white)),
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _searchController,
              style: const TextStyle(color: Colors.white),
              onSubmitted: _searchInfluencer,
              decoration: InputDecoration(
                labelText: "Search influencer username",
                labelStyle: const TextStyle(color: Colors.white70),
                filled: true,
                fillColor: Colors.white12,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10.0)),
                prefixIcon: const Icon(Icons.search, color: Colors.white),
              ),
            ),
            const SizedBox(height: 20),
            if (isLoading) const CircularProgressIndicator(color: Colors.white),
          ],
        ),
      ),
    );
  }
}
