import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'providers/theme_provider.dart';

// ✅ Import All Screens
import 'screens/splash_screen.dart';
import 'screens/intro_screen.dart';
import 'screens/login_screen.dart';
import 'screens/signup_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/profile_analysis_screen.dart';
import 'screens/brand_analysis_screen.dart';
import 'screens/influencer_analysis_screen.dart';
import 'screens/hashtag_analysis_screen.dart';
import 'screens/brand_input_screen.dart';
import 'screens/influencer_profile_screen.dart';
import 'screens/sentiment_tab.dart';
import 'screens/engagement_tab.dart';
import 'screens/followers_tab.dart';
import 'screens/overview_tab.dart';
import 'screens/onboarding_screen.dart';
import 'screens/analysis_result_screen.dart';
import 'screens/analytics_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/explore_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SharedPreferences prefs = await SharedPreferences.getInstance();

  bool isDarkMode = prefs.getBool('isDarkMode') ?? false;
  String firstName = prefs.getString('firstName') ?? 'User';

  runApp(
    ChangeNotifierProvider(
      create: (_) => ThemeProvider(initialDarkMode: isDarkMode),
      child: MyApp(firstName: firstName),
    ),
  );
}

class MyApp extends StatelessWidget {
  final String firstName;

  const MyApp({super.key, required this.firstName});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Zore AI',
      themeMode: themeProvider.themeMode,
      theme: _lightTheme(),
      darkTheme: _darkTheme(),
      home: SplashScreen(), // ❌ removed const
      onGenerateRoute: (settings) => _handleRoutes(settings),
    );
  }

  Route<dynamic> _handleRoutes(RouteSettings settings) {
    final Object? args = settings.arguments;
    Map<String, dynamic> arguments = (args is Map<String, dynamic>) ? args : {};

    switch (settings.name) {
      case '/':
        return MaterialPageRoute(builder: (context) => IntroScreen());
      case '/login':
        return MaterialPageRoute(builder: (context) => LoginScreen());
      case '/signup':
        return MaterialPageRoute(builder: (context) => SignUpScreen());
      case '/onboarding':
        return MaterialPageRoute(builder: (context) => OnboardingScreen());
      case '/dashboard':
        return MaterialPageRoute(
          builder: (context) => DashboardScreen(firstName: arguments['firstName'] ?? firstName),
        );
      case '/profile-analysis':
        return MaterialPageRoute(builder: (context) => ProfileAnalysisScreen());
      case '/brand-analysis':
        return MaterialPageRoute(
          builder: (context) => BrandAnalysisScreen(
            brandUsername: arguments['brandUsername'] ?? '',
          ),
        );
      case '/brand-input':
        return MaterialPageRoute(builder: (context) => BrandInputScreen());
      case '/influencer-analysis':
        return MaterialPageRoute(builder: (context) => InfluencerAnalysisScreen());
      case '/influencer-profile':
        return MaterialPageRoute(
          builder: (context) => InfluencerProfileScreen(
            username: arguments['username'] ?? '',
          ),
        );
      case '/hashtag-analysis':
        return MaterialPageRoute(builder: (context) => HashtagAnalysisScreen());
      case '/sentiment-tab':
        return MaterialPageRoute(builder: (context) => SentimentScreen());
      case '/engagement-tab':
        return MaterialPageRoute(builder: (context) => EngagementScreen());
      case '/followers-tab':
        return MaterialPageRoute(builder: (context) => FollowersScreen());
      case '/overview-tab':
        return MaterialPageRoute(
          builder: (context) => OverviewScreen(username: arguments['username'] ?? ''),
        );
      case '/analysis-result':
        return MaterialPageRoute(
          builder: (context) => AnalysisResultScreen(
            name: arguments['name'] ?? 'Unknown',
            profilePicUrl: arguments['profilePicUrl'] ?? '',
            sentiments: arguments['sentiments'] ?? {},
            recentPosts: arguments['recentPosts'] ?? [],
          ),
        );
      case '/explore':
        return MaterialPageRoute(builder: (context) => ExploreScreen());
      case '/analytics':
        return MaterialPageRoute(builder: (context) => AnalyticsScreen(firstName: firstName));
      case '/profile':
        return MaterialPageRoute(builder: (context) => ProfileScreen());
      case '/trending-posts':
        return MaterialPageRoute(builder: (context) => ExploreScreen(section: 'trending_posts'));
      case '/upcoming-events':
        return MaterialPageRoute(builder: (context) => ExploreScreen(section: 'upcoming_events'));
      case '/new-creators':
        return MaterialPageRoute(builder: (context) => ExploreScreen(section: 'new_creators'));
      default:
        return MaterialPageRoute(builder: (context) => _errorPage());
    }
  }

  ThemeData _lightTheme() {
    return ThemeData(
      brightness: Brightness.light,
      primarySwatch: Colors.deepPurple,
      textTheme: GoogleFonts.poppinsTextTheme(ThemeData.light().textTheme),
      scaffoldBackgroundColor: Colors.white,
      iconTheme: const IconThemeData(color: Colors.black),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }

  ThemeData _darkTheme() {
    return ThemeData(
      brightness: Brightness.dark,
      primarySwatch: Colors.deepPurple,
      textTheme: GoogleFonts.poppinsTextTheme(ThemeData.dark().textTheme),
      scaffoldBackgroundColor: const Color(0xFF121212),
      cardColor: const Color(0xFF1E1E1E),
      iconTheme: const IconThemeData(color: Colors.white),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.deepPurple,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }

  Widget _errorPage() {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Text(
          '404 - Page Not Found',
          style: GoogleFonts.poppins(color: Colors.white, fontSize: 20),
        ),
      ),
    );
  }
}
