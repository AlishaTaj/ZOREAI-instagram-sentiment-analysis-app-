import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:async';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    // Navigate to the next screen after 2 seconds
    Timer(Duration(seconds: 5), () {
      Navigator.pushReplacementNamed(context, '/onboarding');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF6c05ab), Color(0xFFe191de)],  // New Gradient
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Logo - adjusted the size for better fitting
              Image.asset(
                'assets/images/logo-zoreai.png',
                height: 120,
                width: 120,
                fit: BoxFit.contain,  // Ensure logo maintains aspect ratio
              ),
              const SizedBox(height: 20),

              // Main title with a premium feel
              Text(
                'ZORE AI',
                style: GoogleFonts.poppins(
                  color: Colors.white,
                  fontSize: 42,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.2,  // Added letter spacing for premium look
                ),
              ),
              const SizedBox(height: 10),

              // Tagline with refined styling
              Text(
                'Unlocking AI-Driven Insights',
                style: GoogleFonts.poppins(
                  color: Colors.white70,
                  fontSize: 18,
                  fontWeight: FontWeight.w500,  // Slightly refined weight
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 30),

              // Illustration image
              Image.asset(
                'assets/images/social_illustration.png',
                height: 250,
                width: 250,  // Adjust size for better presentation
                fit: BoxFit.contain,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
