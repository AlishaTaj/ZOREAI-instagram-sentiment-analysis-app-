// 📁 components/quick_stats.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class QuickStats extends StatelessWidget {
  const QuickStats({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        _buildStatCard('Followers', '12.4k', Icons.person_outline),
        _buildStatCard('Engagement', '8.7%', Icons.trending_up),
        _buildStatCard('Reach', '32k', Icons.visibility_outlined),
      ],
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon) {
    return Expanded(
      child: Card(
        color: Colors.black,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            children: [
              Icon(icon, color: Color(0xFFe191de), size: 30),
              SizedBox(height: 8),
              Text(value, style: GoogleFonts.poppins(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold)),
              Text(title, style: GoogleFonts.poppins(fontSize: 14, color: Colors.white)),
            ],
          ),
        ),
      ),
    );
  }
}
