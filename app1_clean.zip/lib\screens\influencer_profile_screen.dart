import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:open_file/open_file.dart';

class InfluencerProfileScreen extends StatefulWidget {
  final String username;
  const InfluencerProfileScreen({super.key, required this.username});

  @override
  State<InfluencerProfileScreen> createState() => _InfluencerProfileScreenState();
}

class _InfluencerProfileScreenState extends State<InfluencerProfileScreen> {
  Map<String, dynamic>? influencer;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchInfluencerData();
  }

  Future<void> fetchInfluencerData() async {
    final url = Uri.parse("http://127.0.0.1:5000/influencers/api/${widget.username}");
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        setState(() {
          influencer = Map<String, dynamic>.from(jsonDecode(response.body));
          isLoading = false;
        });
      } else {
        setState(() => isLoading = false);
      }
    } catch (e) {
      print("Error fetching influencer: $e");
      setState(() => isLoading = false);
    }
  }

  Future<void> downloadPDF() async {
    final url = Uri.parse("http://127.0.0.1:5000/influencer/pdf/${widget.username}");
    try {
      final response = await http.get(url);
      print("PDF Response status: ${response.statusCode}");
      if (response.statusCode == 200) {
        final dir = await getApplicationDocumentsDirectory();
        final filePath = '${dir.path}/${widget.username}_report.pdf';
        final file = File(filePath);
        await file.writeAsBytes(response.bodyBytes);
        final result = await OpenFile.open(filePath);
        print("OpenFile result: ${result.message}");
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("❌ Failed to download PDF")),
        );
      }
    } catch (e) {
      print("Error downloading PDF: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("❌ Error occurred during PDF download")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text("@${widget.username}", style: GoogleFonts.poppins(color: Colors.white)),
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: const Icon(Icons.download, color: Colors.white),
            onPressed: downloadPDF,
          )
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: Colors.white))
          : influencer == null
          ? Center(child: Text("Influencer not found", style: GoogleFonts.poppins(color: Colors.red)))
          : SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            CircleAvatar(
              radius: 50,
              backgroundColor: Colors.white12,
              child: const Icon(Icons.person, size: 50, color: Colors.white),
            ),
            const SizedBox(height: 10),
            Text(
              influencer!['name'] ?? 'Unknown',
              style: GoogleFonts.poppins(fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold),
            ),
            Text(influencer!['niche'] ?? '', style: GoogleFonts.poppins(color: Colors.white70)),
            const SizedBox(height: 20),
            _buildStatsCard(),
            _buildSentimentCard(),
            _buildAudienceCard(),
            _buildSummaryCard(),
          ],
        ),
      ),
    );
  }

  Widget _buildStatsCard() {
    final trendData = (influencer!['trendline'] as List?)?.map((e) => (e as num).toDouble()).toList() ?? [];
    return _buildCard(
      title: "Engagement Metrics",
      children: [
        _dataRow("Followers", _formatNumber(influencer!['followers'] ?? 0)),
        _dataRow("Brand Deals", (influencer!['brand_deals'] as List?)?.join(", ") ?? "N/A"),
        const SizedBox(height: 10),
        if (trendData.isNotEmpty) _buildLineChart(trendData),
      ],
    );
  }

  Widget _buildSentimentCard() {
    final score = (influencer!['sentiment_score'] as num?)?.toDouble() ?? 0.0;
    return _buildCard(
      title: "Sentiment Score",
      children: [
        _dataRow("Score", "${(score * 100).toStringAsFixed(1)}%"),
        _sentimentBar(score * 100),
      ],
    );
  }

  Widget _buildAudienceCard() {
    final countries = (influencer!['top_countries'] as List?)?.cast<String>() ?? [];
    return _buildCard(
      title: "Audience Insights",
      children: [
        _dataRow("Top Countries", countries.join(", ")),
        _dataRow("Age Group", influencer!['age_group'] ?? 'N/A'),
      ],
    );
  }

  Widget _buildSummaryCard() {
    final summary = influencer!['gpt_summary'] ?? "No summary available.";
    return _buildCard(
      title: "GPT Summary",
      children: [Text(summary, style: GoogleFonts.poppins(color: Colors.white70))],
    );
  }

  Widget _buildCard({required String title, required List<Widget> children}) {
    return Card(
      color: Colors.white12,
      margin: const EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: GoogleFonts.poppins(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _dataRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: GoogleFonts.poppins(color: Colors.white70)),
          Flexible(
            child: Text(value, style: GoogleFonts.poppins(color: Colors.white), overflow: TextOverflow.ellipsis),
          ),
        ],
      ),
    );
  }

  Widget _sentimentBar(double score) {
    Color barColor;
    if (score >= 75) {
      barColor = Colors.greenAccent;
    } else if (score >= 50) {
      barColor = Colors.orangeAccent;
    } else {
      barColor = Colors.redAccent;
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: LinearProgressIndicator(
            value: score.clamp(0, 100) / 100,
            minHeight: 8,
            backgroundColor: Colors.white24,
            color: barColor,
          ),
        ),
      ],
    );
  }

  Widget _buildLineChart(List<double> data) {
    return SizedBox(
      height: 160,
      child: LineChart(
        LineChartData(
          titlesData: FlTitlesData(show: true),
          gridData: FlGridData(show: true),
          borderData: FlBorderData(show: false),
          lineBarsData: [
            LineChartBarData(
              isCurved: true,
              spots: data.asMap().entries.map((e) => FlSpot(e.key.toDouble(), e.value)).toList(),
              barWidth: 3,
              colors: [Colors.purpleAccent],
              dotData: FlDotData(show: true),
            )
          ],
        ),
      ),
    );
  }

  String _formatNumber(int number) {
    if (number >= 1000000) return "${(number / 1000000).toStringAsFixed(1)}M";
    if (number >= 1000) return "${(number / 1000).toStringAsFixed(1)}K";
    return "$number";
  }
}
