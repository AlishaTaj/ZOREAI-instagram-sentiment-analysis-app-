// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:http/http.dart' as http;
// import 'dart:convert';
//
// class OverviewScreen extends StatelessWidget {
//   final String username;
//
//   const OverviewScreen({super.key, required this.username});
//
//   Future<Map<String, dynamic>> fetchOverviewData() async {
//     try {
//       final response = await http.post(
//         Uri.parse('http://127.0.0.1:5000/requestjson'),
//         headers: {'Content-Type': 'application/json'},
//         body: jsonEncode({'type': 'Public', 'login_id': username}),
//       );
//
//       if (response.statusCode == 200) {
//         return jsonDecode(response.body);
//       } else {
//         throw Exception("Failed to load data");
//       }
//     } catch (e) {
//       throw Exception("Failed to connect to server");
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Overview", style: GoogleFonts.poppins(color: Colors.white)),
//         backgroundColor: Colors.black,
//         iconTheme: IconThemeData(color: Colors.white),
//       ),
//       backgroundColor: Colors.black,
//       body: FutureBuilder<Map<String, dynamic>>(
//         future: fetchOverviewData(),
//         builder: (context, snapshot) {
//           if (snapshot.connectionState == ConnectionState.waiting) {
//             return Center(child: CircularProgressIndicator(color: Colors.white));
//           } else if (snapshot.hasError) {
//             return Center(
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Text(
//                     "Error loading data",
//                     style: GoogleFonts.poppins(color: Colors.redAccent, fontSize: 18),
//                   ),
//                   SizedBox(height: 10),
//                   ElevatedButton(
//                     onPressed: () {
//                       Navigator.pushReplacement(
//                         context,
//                         MaterialPageRoute(builder: (context) => OverviewScreen(username: username)),
//                       );
//                     },
//                     style: ElevatedButton.styleFrom(
//                       backgroundColor: Colors.white,
//                       foregroundColor: Colors.black,
//                     ),
//                     child: Text("Retry", style: GoogleFonts.poppins(fontSize: 16)),
//                   ),
//                 ],
//               ),
//             );
//           } else {
//             final data = snapshot.data!;
//             return SingleChildScrollView(
//               padding: EdgeInsets.all(16.0),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(
//                     "Sentiment Analysis for $username",
//                     style: GoogleFonts.poppins(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold),
//                   ),
//                   SizedBox(height: 20),
//                   _buildCard(
//                     title: "Overall Sentiment",
//                     value: data['Value'] ?? 'N/A',
//                     color: Colors.greenAccent,
//                   ),
//                   _buildCard(
//                     title: "Total Followers",
//                     value: "${data['followers'] ?? 'N/A'}",
//                     color: Colors.white,
//                   ),
//                   _buildCard(
//                     title: "Engagement Rate",
//                     value: "${data['engagement_rate'] ?? 'N/A'}%",
//                     color: Colors.white,
//                   ),
//                   SizedBox(height: 20),
//                   Text(
//                     "More Insights",
//                     style: GoogleFonts.poppins(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold),
//                   ),
//                   SizedBox(height: 10),
//                   _buildInsightsSection(data),
//                 ],
//               ),
//             );
//           }
//         },
//       ),
//     );
//   }
//
//   // Reusable Card Widget
//   Widget _buildCard({required String title, required String value, required Color color}) {
//     return Card(
//       color: Colors.white12,
//       margin: EdgeInsets.symmetric(vertical: 10),
//       shape: RoundedRectangleBorder(
//         borderRadius: BorderRadius.circular(10),
//       ),
//       child: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Row(
//           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//           children: [
//             Text(
//               title,
//               style: GoogleFonts.poppins(color: Colors.white70, fontSize: 16),
//             ),
//             Text(
//               value,
//               style: GoogleFonts.poppins(color: color, fontSize: 16, fontWeight: FontWeight.bold),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   // More Insights Section
//   Widget _buildInsightsSection(Map<String, dynamic> data) {
//     return Column(
//       children: [
//         _buildCard(
//           title: "Average Likes",
//           value: "${data['avg_likes'] ?? 'N/A'}",
//           color: Colors.white,
//         ),
//         _buildCard(
//           title: "Average Comments",
//           value: "${data['avg_comments'] ?? 'N/A'}",
//           color: Colors.white,
//         ),
//         _buildCard(
//           title: "Average Shares",
//           value: "${data['avg_shares'] ?? 'N/A'}",
//           color: Colors.white,
//         ),
//       ],
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class OverviewScreen extends StatelessWidget {
  final String username;

  const OverviewScreen({super.key, required this.username});

  Future<Map<String, dynamic>> fetchOverviewData() async {
    try {
      final response = await http.post(
        Uri.parse('http://127.0.0.1:5000/requestjson'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'type': 'Public', 'login_id': username}),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception("Failed to load data");
      }
    } catch (e) {
      throw Exception("Failed to connect to server");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Overview", style: GoogleFonts.poppins(color: Colors.white)),
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      backgroundColor: Colors.black,
      body: FutureBuilder<Map<String, dynamic>>(
        future: fetchOverviewData(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: Colors.white));
          } else if (snapshot.hasError) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Error loading data",
                    style: GoogleFonts.poppins(color: Colors.redAccent, fontSize: 18),
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => OverviewScreen(username: username)),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black,
                    ),
                    child: Text("Retry", style: GoogleFonts.poppins(fontSize: 16)),
                  ),
                ],
              ),
            );
          } else {
            final data = snapshot.data!;
            return SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Sentiment Analysis for $username",
                    style: GoogleFonts.poppins(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 20),
                  _buildCard(
                    title: "Overall Sentiment",
                    value: data['Value'] ?? 'N/A',
                    color: Colors.greenAccent,
                  ),
                  _buildCard(
                    title: "Total Followers",
                    value: "${data['followers'] ?? 'N/A'}",
                    color: Colors.white,
                  ),
                  _buildCard(
                    title: "Engagement Rate",
                    value: data['engagement_rate'] != null ? "${data['engagement_rate']}%" : "N/A",
                    color: Colors.white,
                  ),
                  const SizedBox(height: 20),
                  Text(
                    "More Insights",
                    style: GoogleFonts.poppins(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  _buildInsightsSection(data),
                ],
              ),
            );
          }
        },
      ),
    );
  }

  Widget _buildCard({required String title, required String value, required Color color}) {
    return Card(
      color: Colors.white12,
      margin: const EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(title, style: GoogleFonts.poppins(color: Colors.white70, fontSize: 16)),
            Text(value, style: GoogleFonts.poppins(color: color, fontSize: 16, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  Widget _buildInsightsSection(Map<String, dynamic> data) {
    return Column(
      children: [
        _buildCard(
          title: "Average Likes",
          value: "${data['avg_likes'] ?? 'N/A'}",
          color: Colors.white,
        ),
        _buildCard(
          title: "Average Comments",
          value: "${data['avg_comments'] ?? 'N/A'}",
          color: Colors.white,
        ),
        _buildCard(
          title: "Average Shares",
          value: "${data['avg_shares'] ?? 'N/A'}",
          color: Colors.white,
        ),
      ],
    );
  }
}
