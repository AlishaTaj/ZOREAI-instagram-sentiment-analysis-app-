// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
//
// class EngagementScreen extends StatefulWidget {
//   const EngagementScreen({super.key});
//
//   @override
//   _EngagementScreenState createState() => _EngagementScreenState();
// }
//
// class _EngagementScreenState extends State<EngagementScreen> {
//   bool isLoading = true;
//   List<Map<String, String>> engagementData = [
//     {"metric": "Likes", "value": "1200"},
//     {"metric": "Comments", "value": "300"},
//     {"metric": "Shares", "value": "150"},
//     {"metric": "Saves", "value": "200"},
//   ];
//
//   @override
//   void initState() {
//     super.initState();
//     _fetchEngagementData();
//   }
//
//   Future<void> _fetchEngagementData() async {
//     await Future.delayed(Duration(seconds: 2)); // Simulate data fetching delay
//     setState(() {
//       isLoading = false;
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text(
//           "Engagement Metrics",
//           style: GoogleFonts.poppins(color: Colors.white),
//         ),
//         backgroundColor: Colors.black,
//         iconTheme: IconThemeData(color: Colors.white),
//       ),
//       backgroundColor: Colors.black,
//       body: isLoading
//           ? Center(
//         child: CircularProgressIndicator(color: Colors.white),
//       )
//           : Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: ListView.builder(
//           itemCount: engagementData.length,
//           itemBuilder: (context, index) {
//             return Card(
//               color: Colors.white12,
//               shape: RoundedRectangleBorder(
//                 borderRadius: BorderRadius.circular(10),
//               ),
//               margin: EdgeInsets.symmetric(vertical: 8),
//               child: ListTile(
//                 leading: Icon(
//                   Icons.analytics,
//                   color: Colors.white70,
//                 ),
//                 title: Text(
//                   engagementData[index]['metric'] ?? '',
//                   style: GoogleFonts.poppins(
//                     color: Colors.white,
//                     fontWeight: FontWeight.bold,
//                   ),
//                 ),
//                 trailing: Text(
//                   engagementData[index]['value'] ?? '',
//                   style: GoogleFonts.poppins(
//                     color: Colors.white70,
//                     fontSize: 16,
//                   ),
//                 ),
//               ),
//             );
//           },
//         ),
//       ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class EngagementScreen extends StatefulWidget {
  const EngagementScreen({super.key});

  @override
  _EngagementScreenState createState() => _EngagementScreenState();
}

class _EngagementScreenState extends State<EngagementScreen> {
  bool isLoading = true;
  List<Map<String, String>> engagementData = [];

  @override
  void initState() {
    super.initState();
    _fetchEngagementData();
  }

  Future<void> _fetchEngagementData() async {
    await Future.delayed(const Duration(seconds: 2));
    setState(() {
      engagementData = [
        {"metric": "Likes", "value": "1200"},
        {"metric": "Comments", "value": "300"},
        {"metric": "Shares", "value": "150"},
        {"metric": "Saves", "value": "200"},
      ];
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Engagement Metrics", style: GoogleFonts.poppins(color: Colors.white)),
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      backgroundColor: Colors.black,
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: Colors.white))
          : Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView.builder(
          itemCount: engagementData.length,
          itemBuilder: (context, index) {
            return Card(
              color: Colors.white12,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: ListTile(
                leading: const Icon(Icons.analytics, color: Colors.white70),
                title: Text(
                  engagementData[index]['metric'] ?? '',
                  style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                trailing: Text(
                  engagementData[index]['value'] ?? '',
                  style: GoogleFonts.poppins(color: Colors.white70, fontSize: 16),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
