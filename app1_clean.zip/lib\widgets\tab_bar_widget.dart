import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class TabBarWidget extends StatelessWidget {
  final TabController tabController;

  const TabBarWidget({Key? key, required this.tabController}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TabBar(
      controller: tabController,
      isScrollable: true,
      indicatorColor: Colors.white,
      labelColor: Colors.white,
      unselectedLabelColor: Colors.white54,
      labelStyle: GoogleFonts.poppins(fontWeight: FontWeight.bold),
      unselectedLabelStyle: GoogleFonts.poppins(),
      tabs: [
        Tab(text: 'Overview'),
        Tab(text: 'Engagement'),
        Tab(text: 'Content'),
        Tab(text: 'Sentiment'),
        Tab(text: 'Followers'),
      ],
    );
  }
}