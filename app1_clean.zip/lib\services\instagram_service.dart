import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  // 👇 Update this based on platform
  static const String baseUrl = 'http://10.0.2.2:5000/analyze'; // Android emulator
  // Use http://localhost:5000 for iOS simulator or Flutter Web
  // Use your PC IP (e.g. http://192.168.x.x:5000) for real device

  // ✅ Profile Sentiment
  static Future<Map<String, dynamic>> analyzeProfile(String username) async {
    final url = Uri.parse('$baseUrl/profile');
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'username': username}),
    );
    return jsonDecode(response.body);
  }

  // ✅ Brand Analysis
  static Future<Map<String, dynamic>> analyzeBrand(String username) async {
    final url = Uri.parse('$baseUrl/brand');
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'username': username}),
    );
    return jsonDecode(response.body);
  }

  // ✅ Influencer Analysis
  static Future<Map<String, dynamic>> analyzeInfluencer(String username) async {
    final url = Uri.parse('$baseUrl/influencer');
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'username': username}),
    );
    return jsonDecode(response.body);
  }

  // ✅ Hashtag Analysis
  static Future<Map<String, dynamic>> analyzeHashtag(String hashtag) async {
    final url = Uri.parse('$baseUrl/hashtag');
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'hashtag': hashtag}),
    );
    return jsonDecode(response.body);
  }
}
