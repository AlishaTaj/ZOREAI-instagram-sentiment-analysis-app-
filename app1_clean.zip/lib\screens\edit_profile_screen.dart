// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
//
// class EditProfileScreen extends StatefulWidget {
//   final String name;
//   final String bio;
//   final String email;
//
//   EditProfileScreen({required this.name, required this.bio, required this.email});
//
//   @override
//   _EditProfileScreenState createState() => _EditProfileScreenState();
// }
//
// class _EditProfileScreenState extends State<EditProfileScreen> {
//   late TextEditingController nameController;
//   late TextEditingController bioController;
//   late TextEditingController emailController;
//
//   @override
//   void initState() {
//     super.initState();
//     nameController = TextEditingController(text: widget.name);
//     bioController = TextEditingController(text: widget.bio);
//     emailController = TextEditingController(text: widget.email);
//   }
//
//   void _saveProfile() {
//     Navigator.pop(context, {
//       'name': nameController.text,
//       'bio': bioController.text,
//       'email': emailController.text,
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text("Edit Profile")),
//       body: Padding(
//         padding: const EdgeInsets.all(20),
//         child: Column(
//           children: [
//             TextField(controller: nameController, decoration: const InputDecoration(labelText: "Name")),
//             TextField(controller: bioController, decoration: const InputDecoration(labelText: "Bio")),
//             TextField(controller: emailController, decoration: const InputDecoration(labelText: "Email")),
//             const SizedBox(height: 20),
//             ElevatedButton(onPressed: _saveProfile, child: Text("Save")),
//           ],
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class EditProfileScreen extends StatefulWidget {
  final String name;
  final String bio;
  final String email;

  const EditProfileScreen({super.key, required this.name, required this.bio, required this.email});

  @override
  _EditProfileScreenState createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  late TextEditingController nameController;
  late TextEditingController bioController;
  late TextEditingController emailController;
  bool isSaving = false;

  @override
  void initState() {
    super.initState();
    nameController = TextEditingController(text: widget.name);
    bioController = TextEditingController(text: widget.bio);
    emailController = TextEditingController(text: widget.email);
  }

  Future<void> _saveProfile() async {
    final name = nameController.text.trim();
    final bio = bioController.text.trim();
    final email = emailController.text.trim();

    if (name.isEmpty || email.isEmpty || !email.contains("@")) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please enter valid name and email")),
      );
      return;
    }

    setState(() => isSaving = true);

    try {
      final response = await http.post(
        Uri.parse("http://127.0.0.1:5000/update_profile"),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "name": name,
          "bio": bio,
          "email": email,
        }),
      );

      if (response.statusCode == 200) {
        Navigator.pop(context, {
          'name': name,
          'bio': bio,
          'email': email,
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Failed to update profile")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    } finally {
      setState(() => isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final textStyle = GoogleFonts.poppins();

    return Scaffold(
      appBar: AppBar(
        title: Text("Edit Profile", style: textStyle.copyWith(color: Colors.white)),
        backgroundColor: Colors.black,
      ),
      backgroundColor: Colors.black,
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: nameController,
              style: textStyle.copyWith(color: Colors.white),
              decoration: const InputDecoration(
                labelText: "Name",
                labelStyle: TextStyle(color: Colors.white70),
                filled: true,
                fillColor: Colors.white12,
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: bioController,
              style: textStyle.copyWith(color: Colors.white),
              decoration: const InputDecoration(
                labelText: "Bio",
                labelStyle: TextStyle(color: Colors.white70),
                filled: true,
                fillColor: Colors.white12,
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: emailController,
              style: textStyle.copyWith(color: Colors.white),
              decoration: const InputDecoration(
                labelText: "Email",
                labelStyle: TextStyle(color: Colors.white70),
                filled: true,
                fillColor: Colors.white12,
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            isSaving
                ? const CircularProgressIndicator(color: Colors.white)
                : ElevatedButton(
              onPressed: _saveProfile,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.white),
              child: Text("Save", style: textStyle.copyWith(color: Colors.black)),
            ),
          ],
        ),
      ),
    );
  }
}
