import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class HashtagAnalysisScreen extends StatefulWidget {
  const HashtagAnalysisScreen({super.key});

  @override
  _HashtagAnalysisScreenState createState() => _HashtagAnalysisScreenState();
}

class _HashtagAnalysisScreenState extends State<HashtagAnalysisScreen> {
  final TextEditingController _hashtagController = TextEditingController();
  String _hashtag = '';
  bool _isLoading = false;
  Map<String, dynamic> _hashtagData = {};

  void _analyzeHashtag() {
    setState(() {
      _isLoading = true;
      _hashtag = _hashtagController.text.trim();
    });

    Future.delayed(const Duration(seconds: 1), () {
      final random = Random();

      int reach = random.nextInt(50000) + 10000;
      int impressions = reach + random.nextInt(20000);
      double engagementRate = double.parse((random.nextDouble() * 10).toStringAsFixed(2));

      int positive = random.nextInt(30) + 40; // 40–69
      int neutral = random.nextInt(100 - positive);
      int negative = 100 - positive - neutral;

      List<String> allHashtags = [
        '#FutureOfTech',
        '#TechTrends',
        '#AIInnovation',
        '#NextGen',
        '#FlutterDev',
        '#CyberScope',
        '#CleanUI',
        '#CloudBuzz',
        '#CodeFlow',
        '#SmartLife'
      ]..shuffle();

      setState(() {
        _hashtagData = {
          'reach': reach,
          'impressions': impressions,
          'engagement_rate': engagementRate,
          'sentiment': {
            'positive': positive,
            'neutral': neutral,
            'negative': negative,
          },
          'suggestions': allHashtags.take(3).toList()
        };
        _isLoading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text('Hashtag Analysis', style: GoogleFonts.poppins(color: Colors.white)),
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            _buildSearchBar(),
            const SizedBox(height: 20),
            _isLoading
                ? const Expanded(
              child: Center(child: CircularProgressIndicator(color: Colors.white)),
            )
                : _hashtag.isNotEmpty
                ? Expanded(
              child: ListView(
                children: [
                  _buildHashtagOverview(),
                  _buildSentimentAnalysis(),
                  _buildEngagementMetrics(),
                  _buildHashtagSuggestions(),
                ],
              ),
            )
                : Expanded(
              child: Center(
                child: Text(
                  "Enter a hashtag to see the analysis",
                  style: GoogleFonts.poppins(color: Colors.white70),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchBar() {
    return TextField(
      controller: _hashtagController,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: 'Enter Hashtag',
        labelStyle: const TextStyle(color: Colors.white70),
        filled: true,
        fillColor: Colors.white12,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10.0)),
        prefixIcon: const Icon(Icons.search, color: Colors.white),
      ),
      onSubmitted: (_) => _analyzeHashtag(),
    );
  }

  Widget _buildHashtagOverview() {
    return _buildCard(
      title: 'Hashtag Overview',
      content: Column(
        children: [
          _buildDataRow('Reach', _hashtagData['reach'].toString()),
          _buildDataRow('Impressions', _hashtagData['impressions'].toString()),
          _buildDataRow('Engagement Rate', '${_hashtagData['engagement_rate']}%'),
        ],
      ),
    );
  }

  Widget _buildSentimentAnalysis() {
    final sentiment = _hashtagData['sentiment'] ?? {};
    return _buildCard(
      title: 'Sentiment Analysis',
      content: Column(
        children: [
          _buildDataRow('Positive', '${sentiment['positive']}%', Colors.greenAccent),
          _buildDataRow('Neutral', '${sentiment['neutral']}%', Colors.yellow),
          _buildDataRow('Negative', '${sentiment['negative']}%', Colors.red),
        ],
      ),
    );
  }

  Widget _buildEngagementMetrics() {
    final reach = _hashtagData['reach'] ?? 10000;
    return _buildCard(
      title: 'Engagement Metrics',
      content: Column(
        children: [
          _buildDataRow('Likes', '${(1000 + reach ~/ 10)}'),
          _buildDataRow('Shares', '${(500 + reach ~/ 25)}'),
          _buildDataRow('Comments', '${(800 + reach ~/ 20)}'),
        ],
      ),
    );
  }

  Widget _buildHashtagSuggestions() {
    final suggestions = List<String>.from(_hashtagData['suggestions'] ?? []);
    return _buildCard(
      title: 'Suggested Hashtags',
      content: Column(
        children: suggestions.map((tag) => _buildDataRow(tag)).toList(),
      ),
    );
  }

  Widget _buildCard({required String title, required Widget content}) {
    return Card(
      color: Colors.white12,
      margin: const EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: GoogleFonts.poppins(
                    color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            content,
          ],
        ),
      ),
    );
  }

  Widget _buildDataRow(String label, [String value = '', Color? color]) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: GoogleFonts.poppins(color: Colors.white70)),
          if (value.isNotEmpty)
            Text(value, style: GoogleFonts.poppins(color: color ?? Colors.white70)),
        ],
      ),
    );
  }
}
