import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:salomon_bottom_bar/salomon_bottom_bar.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../providers/theme_provider.dart';

class DashboardScreen extends StatefulWidget {
  final String firstName;

  const DashboardScreen({super.key, required this.firstName});

  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _currentIndex = 0;
  String? _firstName;

  final List<Map<String, dynamic>> trendingItems = [
    {
      "title": "Top 10 Influencers Today",
      "subtitle": "Discover the most engaging influencers.",
      "icon": Icons.star,
      "route": "/explore",
    },
    {
      "title": "Viral Hashtags",
      "subtitle": "Check out the latest trending hashtags.",
      "icon": Icons.tag,
      "route": "/explore",
    },
    {
      "title": "Brand Sentiment Report",
      "subtitle": "How are brands being perceived?",
      "icon": Icons.insights,
      "route": "/analytics",
    },
  ];

  @override
  void initState() {
    super.initState();
    _loadUserName();
  }

  Future<void> _loadUserName() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _firstName = prefs.getString('firstName') ?? widget.firstName;
    });
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final bool isDarkMode = Theme.of(context).brightness == Brightness.dark;

    final Color primaryPurple = const Color(0xFF9D4EDD);
    final Color deepPurple = const Color(0xFF5A189A);
    final Color textColor = isDarkMode ? Colors.white : Colors.black;
    final Color bottomNavColor = isDarkMode ? Colors.black : Colors.white;
    final Color iconColor = isDarkMode ? Colors.white : Colors.black;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Zore AI - Home',
          style: GoogleFonts.poppins(fontSize: 18, color: textColor, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: textColor),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: _buildCustomSwitch(themeProvider, isDarkMode),
          ),
        ],
      ),
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildGreetingText(_firstName ?? "User", deepPurple, primaryPurple),
            const SizedBox(height: 5),
            Text(
              'Welcome back! Explore trending insights & AI-powered analytics.',
              style: GoogleFonts.poppins(fontSize: 14, color: textColor),
              maxLines: 2,
              overflow: TextOverflow.ellipsis, // ✅ Prevents overflow
            ),
            const SizedBox(height: 10),

            // 🚀 **Quick Actions**
            Row(
              children: [
                Expanded(child: _buildQuickAction("Analyze Now", Icons.bar_chart, '/analytics', primaryPurple)),
                const SizedBox(width: 10),
                Expanded(child: _buildQuickAction("Explore Trends", Icons.trending_up, '/explore', deepPurple)),
              ],
            ),
            const SizedBox(height: 10),

            // 🌎 **Trending Section**
            Text("Trending Now 🔥", style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.bold, color: textColor)),
            const SizedBox(height: 8),

            // 📜 **Trending List**
            Expanded(
              child: ListView.builder(
                itemCount: trendingItems.length,
                itemBuilder: (context, index) {
                  return _buildTrendingCard(
                    trendingItems[index]["title"] as String,
                    trendingItems[index]["subtitle"] as String,
                    trendingItems[index]["icon"] as IconData,
                    trendingItems[index]["route"] as String,
                  );
                },
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomNavigationBar(isDarkMode, bottomNavColor, iconColor),
    );
  }

  /// 🎨 **Greeting Text with Gradient**
  Widget _buildGreetingText(String firstName, Color startColor, Color endColor) {
    return ShaderMask(
      shaderCallback: (Rect bounds) {
        return LinearGradient(
          colors: [startColor, endColor],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ).createShader(bounds);
      },
      child: Text(
        'Hello, $firstName! 👋',
        style: GoogleFonts.poppins(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white),
      ),
    );
  }

  /// 🚀 **Quick Action Buttons**
  Widget _buildQuickAction(String title, IconData icon, String route, Color color) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, route),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 18),
            const SizedBox(width: 6),
            Text(title, style: GoogleFonts.poppins(fontSize: 13, color: Colors.white)),
          ],
        ),
      ),
    );
  }

  /// 🔥 **Trending Cards**
  Widget _buildTrendingCard(String title, String subtitle, IconData icon, String route) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, route),
      child: Card(
        margin: const EdgeInsets.only(bottom: 8),
        elevation: 3,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        child: ListTile(
          leading: Icon(icon, color: Colors.deepPurple, size: 20),
          title: Text(title, style: GoogleFonts.poppins(fontSize: 15, fontWeight: FontWeight.bold)),
          subtitle: Text(subtitle, style: GoogleFonts.poppins(fontSize: 12)),
          trailing: Icon(Icons.arrow_forward_ios, size: 14),
        ),
      ),
    );
  }

  /// 🎨 **Bottom Navigation Bar**
  Widget _buildBottomNavigationBar(bool isDarkMode, Color bottomNavColor, Color iconColor) {
    return SalomonBottomBar(
      backgroundColor: bottomNavColor,
      currentIndex: _currentIndex,
      onTap: (i) {
        setState(() {
          _currentIndex = i;
          switch (i) {
            case 0:
              Navigator.pushNamed(context, "/home");
              break;
            case 1:
              Navigator.pushNamed(context, "/explore");
              break;
            case 2:
              Navigator.pushNamed(context, "/analytics");
              break;
            case 3:
              Navigator.pushNamed(context, "/profile");
              break;
          }
        });
      },
      items: [
        SalomonBottomBarItem(icon: Icon(Icons.home, color: iconColor), title: Text("Home", style: TextStyle(color: iconColor))),
        SalomonBottomBarItem(icon: Icon(Icons.search, color: iconColor), title: Text("Explore", style: TextStyle(color: iconColor))),
        SalomonBottomBarItem(icon: Icon(Icons.analytics, color: iconColor), title: Text("Analytics", style: TextStyle(color: iconColor))),
        SalomonBottomBarItem(icon: Icon(Icons.person, color: iconColor), title: Text("Profile", style: TextStyle(color: iconColor))),
      ],
    );
  }

  /// ✨ **Custom Toggle Switch**
  Widget _buildCustomSwitch(ThemeProvider themeProvider, bool isDarkMode) {
    return Switch(
      value: isDarkMode,
      onChanged: (value) => themeProvider.toggleTheme(value),
    );
  }
}
